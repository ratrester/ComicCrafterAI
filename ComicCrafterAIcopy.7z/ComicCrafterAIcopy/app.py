import streamlit as st
from comic_generator import generate_story, generate_image

st.title("ComicCrafter AI")

prompt = st.text_input("Enter a prompt for your comic story:")

if prompt:
   
    story_parts = generate_story(prompt)

    image = generate_image(prompt)

    st.write("### Introduction")
    st.write(story_parts[0])  
    st.write("### Storyline")
    st.write(story_parts[1]) 
    st.write("### Climax")
    st.write(story_parts[2])  
    st.write("### Moral")
    st.write(story_parts[3])  

    st.image(image, caption="Generated Comic Image")
