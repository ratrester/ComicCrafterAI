from transformers import pipeline

generator = pipeline("text-generation", model="gpt2")

def generate_story(prompt):
    introduction = generator(f"Introduction: {prompt}", max_length=100)[0]['generated_text']
    storyline = generator(f"Storyline: {prompt}", max_length=100)[0]['generated_text']
    climax = generator(f"Climax: {prompt}", max_length=100)[0]['generated_text']
    moral = generator(f"Moral: {prompt}", max_length=100)[0]['generated_text']
    
    return introduction, storyline, climax, moral

from diffusers import StableDiffusionPipeline
import torch

pipe = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4")
pipe.to("cpu")  

def generate_image(prompt):
    # Generate an image from the prompt
    image = pipe(prompt).images[0]
    return image



